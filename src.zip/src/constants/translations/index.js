import en from './en'
import ua from './ua'

const resources = {
  en,
  ua
}

export default resources
