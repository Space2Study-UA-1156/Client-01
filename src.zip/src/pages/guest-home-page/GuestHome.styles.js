export const styles = {
  root: { flex: 1 },
  sectionsWrapper: {
    gap: { sm: '80px', xs: '48px' },
    mt: { sm: '80px', xs: '48px' }
  }
}
