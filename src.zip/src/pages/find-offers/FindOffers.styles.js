export const styles = {
  switch: {
    display: 'flex',
    justifyContent: 'center',
    flexDirection: { sm: 'row', xs: 'column' }
  }
}
