import PageWrapper from '~/components/page-wrapper/PageWrapper'

const Categories = () => {
  return <PageWrapper>Categories</PageWrapper>
}

export default Categories
