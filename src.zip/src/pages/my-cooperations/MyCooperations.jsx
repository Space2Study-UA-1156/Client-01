import PageWrapper from '~/components/page-wrapper/PageWrapper'

const MyCooperations = () => {
  return <PageWrapper>My cooperations</PageWrapper>
}

export default MyCooperations
