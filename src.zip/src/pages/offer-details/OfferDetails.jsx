import PageWrapper from '~/components/page-wrapper/PageWrapper'

const OfferDetails = () => {
  return <PageWrapper>OfferDetails Page</PageWrapper>
}

export default OfferDetails
