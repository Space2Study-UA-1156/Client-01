const StudentProfile = () => {
  return <div>StudentProfile Page Placeholder</div>
}

export default StudentProfile
