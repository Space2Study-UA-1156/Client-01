import PageWrapper from '~/components/page-wrapper/PageWrapper'

const Subjects = () => {
  return <PageWrapper>Subjects</PageWrapper>
}

export default Subjects
