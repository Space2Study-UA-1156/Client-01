import PageWrapper from '~/components/page-wrapper/PageWrapper'

const EditProfile = () => {
  return (
    <PageWrapper>
      <div>EditProfile Page Placeholder</div>
    </PageWrapper>
  )
}

export default EditProfile
