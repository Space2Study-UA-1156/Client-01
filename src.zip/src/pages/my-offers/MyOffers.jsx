import PageWrapper from '~/components/page-wrapper/PageWrapper'

const MyOffers = () => {
  return <PageWrapper>My offers</PageWrapper>
}

export default MyOffers
