export const categoriesMock = [
  { name: 'Languages' },
  { name: 'Mathematics' },
  { name: 'Computer science' },
  { name: 'Music' },
  { name: 'History' }
]

export const languagesMock = [
  { name: 'Chinese' },
  { name: 'Czech' },
  { name: 'Danish' },
  { name: 'Dutch' },
  { name: 'English' },
  { name: 'Estonian' },
  { name: 'Finnish' },
  { name: 'French' },
  { name: 'German' },
  { name: 'Hungarian' },
  { name: 'Icelandic' },
  { name: 'Italian' },
  { name: 'Japanese' },
  { name: 'Korean' },
  { name: 'Norwegian' },
  { name: 'Polish' },
  { name: 'Portuguese (Brazil)' },
  { name: 'Portuguese (Portugal)' },
  { name: 'Romanian' },
  { name: 'Slovak' },
  { name: 'Spanish' },
  { name: 'Swedish' },
  { name: 'Ukrainian' }
]
