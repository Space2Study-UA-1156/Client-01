import { makeStyles } from '@mui/styles'
export const useSelectGroupStyles = makeStyles({
  formControl: {
    minWidth: 120,
    width: '100%'
  }
})
