export const accordionItems = [
  {
    title: 'studentHomePage.faq.findTutor',
    description: 'studentHomePage.faq.findTutorDesription'
  },
  {
    title: 'studentHomePage.faq.bookLeson',
    description: 'studentHomePage.faq.findTutorDesription'
  },
  {
    title: 'studentHomePage.faq.rules',
    description: 'studentHomePage.faq.findTutorDesription'
  },
  {
    title: 'studentHomePage.faq.howPayLesons',
    description: 'studentHomePage.faq.findTutorDesription'
  }
]
