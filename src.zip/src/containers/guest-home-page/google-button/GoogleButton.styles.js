export const styles = {
  google: {
    marginBottom: '16px',
    height: '44px',
    width: '100%',
    overflow: 'hidden'
  }
}
