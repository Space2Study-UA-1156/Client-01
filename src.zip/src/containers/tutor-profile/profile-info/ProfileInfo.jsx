const ProfileInfo = () => {
  return <h1>Tutor profile</h1>
}

export default ProfileInfo
