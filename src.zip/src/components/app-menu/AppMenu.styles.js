export const styles = {
  menu: {
    '& .MuiPaper-root': {
      borderRadius: 0
    },
    left: { xs: '15px', sm: '20px', md: '32px' }
  }
}
