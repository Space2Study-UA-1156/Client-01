export const styles = {
  container: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    mb: '100px'
  }
}
