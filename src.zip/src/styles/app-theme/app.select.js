export const select = {
  styleOverrides: {
    select: {
      padding: '12.5px 14px'
    }
  }
}
