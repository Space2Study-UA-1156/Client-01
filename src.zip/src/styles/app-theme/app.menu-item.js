import palette from './app.pallete'

export const menuItem = {
  styleOverrides: {
    root: {
      '&:hover': { backgroundColor: palette.primary[50] }
    }
  }
}
