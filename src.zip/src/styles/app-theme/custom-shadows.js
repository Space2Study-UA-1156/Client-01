export const mainShadow =
  '0px 5px 6px -3px rgba(144, 164, 174, 0.2), 0px 9px 12px 1px rgba(144, 164, 174,' +
  ' 0.14), 0px 3px 16px 2px rgba(144, 164, 174, 0.12)'

export const commonShadow = '0px 3px 16px 2px rgba(144, 164, 174, 0.12)'

export const commonHoverShadow = '0px 3px 16px 2px rgba(144, 164, 174, 0.56)'

export const smallHoverShadow = '0 3px 1px rgba(144, 164, 174, 0.56)'
